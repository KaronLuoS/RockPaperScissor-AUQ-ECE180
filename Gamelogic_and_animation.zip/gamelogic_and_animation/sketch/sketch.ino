#include "Arduino_LED_Matrix.h"
#include "Arduino_RouterBridge.h"

#include "anim_title.h"
#include "anim_you.h"
#include "anim_win.h"
#include "anim_lose.h"
#include "anim_draw.h"
#include "anim_rock.h"
#include "anim_paper.h"
#include "anim_scissors.h"
#include "anim_hold.h"
#include "anim_nohand.h"
#include "anim_countdown321.h"
#include "anim_countup123.h"
#include "anim_waiting.h"
#include "anim_gamestart.h"
#include "anim_gameend.h"
#include "anim_onemore.h"

ArduinoLEDMatrix matrix;

struct Anim { const uint32_t (*f)[5]; int n; };
#define A(x) { x, (int)(sizeof(x) / sizeof(x[0])) }

Anim anims[] = {
  A(anim_title),
  A(anim_you),
  A(anim_win),
  A(anim_lose),
  A(anim_draw),
  A(anim_rock),
  A(anim_paper),
  A(anim_scissors),
  A(anim_hold),
  A(anim_nohand),
  A(anim_countdown321),
  A(anim_countup123),
  A(anim_waiting),
  A(anim_gamestart),
  A(anim_gameend),
  A(anim_onemore),
};
const int NUM_ANIMS = sizeof(anims) / sizeof(anims[0]);

int currentAnimId = -1;
int currentFrame = 0;
bool looping = false;
bool playing = false;
unsigned long frameStartMs = 0;

void drawCurrent() {
  if (currentAnimId < 0) return;
  const Anim& a = anims[currentAnimId];
  uint32_t frame[4] = {
    a.f[currentFrame][0],
    a.f[currentFrame][1],
    a.f[currentFrame][2],
    a.f[currentFrame][3]
  };
  matrix.loadFrame(frame);
}

int play(int id, bool loop_it) {
  if (id < 0 || id >= NUM_ANIMS) return -1;
  currentAnimId = id;
  currentFrame = 0;
  looping = loop_it;
  playing = true;
  frameStartMs = millis();
  drawCurrent();
  return 0;
}

bool is_playing() {
  return playing;
}

int stop_anim() {
  playing = false;
  uint32_t off[4] = {0, 0, 0, 0};
  matrix.loadFrame(off);
  return 0;
}

int read_hand() {
  static String buf = "";
  while (Serial.available()) {
    char c = Serial.read();
    if (c == '\n' || c == '\r') {
      buf.trim();
      buf.toLowerCase();
      int result = -1;
      if (buf == "rock" || buf == "r") result = 0;
      else if (buf == "paper" || buf == "p") result = 1;
      else if (buf == "scissors" || buf == "s") result = 2;
      buf = "";
      if (result >= 0) return result;
    } else {
      buf += c;
    }
  }
  return -1;
}

void setup() {
  matrix.begin();
  Serial.begin(115200);
  Bridge.begin();
  Bridge.provide("play", play);
  Bridge.provide("is_playing", is_playing);
  Bridge.provide("stop_anim", stop_anim);
  Bridge.provide("read_hand", read_hand);
}

void loop() {
  if (!playing) return;
  const Anim& a = anims[currentAnimId];
  unsigned long now = millis();
  unsigned long dur = a.f[currentFrame][4];
  if (now - frameStartMs >= dur) {
    currentFrame++;
    if (currentFrame >= a.n) {
      if (looping) {
        currentFrame = 0;
      } else {
        playing = false;
        return;
      }
    }
    drawCurrent();
    frameStartMs = now;
  }
}