from arduino.app_utils import *
import random
import time

ANIM = {
    "title": 0, "you": 1, "win": 2, "lose": 3, "draw": 4,
    "rock": 5, "paper": 6, "scissors": 7, "hold": 8, "nohand": 9,
    "countdown": 10, "countup": 11,
    "waiting": 12, "gamestart": 13, "gameend": 14, "onemore": 15,
}
NAMES = ["rock", "paper", "scissors"]

def play_wait(name):
    Bridge.call("play", ANIM[name], False)
    while Bridge.call("is_playing"):
        time.sleep(0.05)

def play_loop_start(name):
    Bridge.call("play", ANIM[name], True)

def stop_anim():
    Bridge.call("stop_anim")

def wait_for_hand():
    """Wait for rock/paper/scissors input from Serial Monitor"""
    print(">>> Enter rock / paper / scissors in the Serial Monitor <<<")
    while True:
        hand = Bridge.call("read_hand")
        if hand >= 0:
            return hand
        time.sleep(0.1)

def judge(player, machine):
    if player == machine:
        return 2
    return 0 if (player - machine) % 3 == 1 else 1

def one_round():
    play_loop_start("hold")
    player = wait_for_hand()
    stop_anim()
    machine = random.randint(0, 2)
    print(f"Player: {NAMES[player]}  Machine: {NAMES[machine]}")
    play_wait(NAMES[machine])
    r = judge(player, machine)
    if r == 2:
        play_wait("draw")
        return "draw"
    play_wait("you")
    if r == 0:
        play_wait("win")
        return "win"
    else:
        play_wait("lose")
        return "lose"

def loop():
    print("=== GAME START ===")
    play_wait("gamestart")
    play_wait("title")
    play_wait("countup")
    while True:
        result = one_round()
        if result == "draw":
            play_wait("onemore")
            continue
        break
    print("=== GAME END ===")
    play_wait("gameend")
    time.sleep(2)

App.run(user_loop=loop)